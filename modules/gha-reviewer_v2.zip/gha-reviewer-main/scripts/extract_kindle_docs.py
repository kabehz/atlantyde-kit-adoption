# extract_kindle_docs.py

Contenido de ejemplo para extract_kindle_docs.py.
